export const environment = {
  production: true,
  apiRoot: 'http://localhost:8080'
};
