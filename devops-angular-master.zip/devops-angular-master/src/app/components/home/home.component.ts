import { Component, OnInit } from '@angular/core';
import { StudentsService, StudentsServiceImpl } from 'src/app/service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [
    {
      provide: StudentsService,
      useClass: StudentsServiceImpl
    }
  ]
})
export class HomeComponent implements OnInit {

  students = [];

  constructor(private studentsService: StudentsService) { }

  ngOnInit(): void {
    this.loadAllStudents();
  }

  loadAllStudents() {
    this.studentsService.getStudentsList().subscribe((res) => {
      this.students = res;
    });
  }

  deleteStudent(student: any) {
    if (confirm(`Are you sure to delete ${student.firstName} ${student.lastName}`)) {
      this.studentsService.deleteStudent(student.id).subscribe(_ => this.loadAllStudents());
    }
  }
}
