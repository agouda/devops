import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentsService, StudentsServiceImpl } from 'src/app/service';

@Component({
  selector: 'app-view-student',
  templateUrl: './view-student.component.html',
  styleUrls: ['./view-student.component.css'],
  providers: [
    {
      provide: StudentsService,
      useClass: StudentsServiceImpl
    }
  ]
})
export class ViewStudentComponent implements OnInit {

  student: any;

  constructor(private studentsService: StudentsService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getStudent(this.route.snapshot.params['id']);
  }

  getStudent(studentId: any) {
    this.studentsService.getStudent(studentId).subscribe((res) => {
      this.student = res;
    });
  }

  deleteStudent(student: any) {
    if (confirm(`Are you sure to delete ${student.firstName} ${student.lastName}`)) {
      this.studentsService.deleteStudent(student.id).subscribe(_ => this.router.navigate(['/home']));
    }
  }
}
