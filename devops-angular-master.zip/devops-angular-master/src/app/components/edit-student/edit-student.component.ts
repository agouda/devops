import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentsService, StudentsServiceImpl } from 'src/app/service';
@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css'],
  providers: [
    {
      provide: StudentsService,
      useClass: StudentsServiceImpl
    }
  ]
})
export class EditStudentComponent implements OnInit {

  id: number;
  submitted = false;
  angForm: FormGroup;

  constructor(private fb: FormBuilder, private studentsService: StudentsService, private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.getStudent(this.route.snapshot.params['id']);
  }

  getStudent(studentId: any) {
    this.studentsService.getStudent(studentId).subscribe((res) => {
      this.id = res.id;
      this.createForm();
      this.angForm.patchValue(res)
    });
  }

  createForm() {
    this.angForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.angForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.angForm.invalid) {
      return;
    }

    // add the student 
    this.studentsService.editStudent(this.id, this.angForm.value).subscribe(_ => this.router.navigate(['/home']));
  }
}
