import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentsService, StudentsServiceImpl } from 'src/app/service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css'],
  providers: [
    {
      provide: StudentsService,
      useClass: StudentsServiceImpl
    }
  ]
})
export class AddStudentComponent implements OnInit {
  submitted = false;
  angForm: FormGroup;

  constructor(private fb: FormBuilder, private studentsService: StudentsService, private router: Router) {
    this.createForm();
  }

  ngOnInit(): void {
  }

  createForm() {
    this.angForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.angForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.angForm.invalid) {
      return;
    }

    // add the student 
    this.studentsService.addStudent(this.angForm.value).subscribe(_ => this.router.navigate(['/home']));
  }
}
