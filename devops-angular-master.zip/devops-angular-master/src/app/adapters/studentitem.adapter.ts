import { Injectable } from '@angular/core';
import { StudentItemDTO } from '../dto/student.dto';
import { Adapter } from './adapter';

@Injectable({
  providedIn: 'root',
})

export class StudentItemAdapter implements Adapter<StudentItemDTO> {
  adapt(item: any): StudentItemDTO {
    return new StudentItemDTO(
      item.id,
      item.firstName,
      item.lastName,
      item.email
    );
  }
}
