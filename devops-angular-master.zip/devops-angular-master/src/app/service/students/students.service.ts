import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export abstract class StudentsService {
  abstract getStudent(itemId: any): Observable<any>;
  abstract getStudentsList(): Observable<any>;
  abstract addStudent(item: any): Observable<any>;
  abstract editStudent(itemId: any, item: any): Observable<any>;
  abstract deleteStudent(itemId: any): Observable<any>;
}
