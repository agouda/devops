import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StudentsService } from './students.service';
import { map } from 'rxjs/operators';
import { StudentItemAdapter } from 'src/app/adapters';
import { environment } from 'src/environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    accept: 'application/json;odata=verbose',
  }),
};

@Injectable({
  providedIn: 'root',
})

export class StudentsServiceImpl implements StudentsService {

  constructor(
    private http: HttpClient,
    private adapter: StudentItemAdapter
  ) { }

  getStudent(itemId: any): Observable<any> {
    return this.http.get(`${environment.apiRoot}/api/students/${itemId}`).pipe(
      map((data: any) => {
        return this.adapter.adapt(data);
      })
    );
  }

  getStudentsList(): Observable<any> {
    return this.http.get(`${environment.apiRoot}/api/students`).pipe(
      map((data: any[]) => {
        return data.map((item) => this.adapter.adapt(item));
      })
    );
  }

  addStudent(item: any): Observable<any> {
    let body = {
      firstName: item.firstName,
      lastName: item.lastName,
      email: item.email
    };
    return this.http.post(`${environment.apiRoot}/api/students`, body, httpOptions);
  }

  editStudent(itemId: any, item: any) {
    let body = {
      firstName: item.firstName,
      lastName: item.lastName,
      email: item.email
    };
    return this.http.put(`${environment.apiRoot}/api/students/${itemId}`, body, httpOptions);
  }

  deleteStudent(itemId: any): Observable<any> {
    return this.http.delete(`${environment.apiRoot}/api/students/${itemId}`, httpOptions);
  }

}
