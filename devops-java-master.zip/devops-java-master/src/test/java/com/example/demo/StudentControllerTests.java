package com.example.demo;

import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;

import java.util.Optional;

import com.example.demo.controller.StudentController;
import com.example.demo.dto.StudentDTO;
import com.example.demo.model.Student;
import com.example.demo.service.StudentService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
@WebMvcTest(StudentController.class)
public class StudentControllerTests {

        @Autowired
        MockMvc mockMvc;

        @Autowired
        ObjectMapper objectMapper; // to stringify Java objects

        @MockBean
        private StudentService studentService;

        // Sanity Test to test if all dependencies are satisfied
        @Test
        public void contextLoads() {
        }

        // API: addStudent
        @Test
        public void shouldAddStudentSuccessfully() throws Exception {
                // 1. Mock the request body
                StudentDTO payload = new StudentDTO("Ahmed", "Gouda", "softgate@hotmail.com");

                // 2. Create mock HTTP request and test it
                mockMvc.perform(post("/api/students").content(objectMapper.writeValueAsString(payload))
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
                                // check response status
                                .andExpect(status().isOk()) // 200
                                // check not error
                                .andExpect(MockMvcResultMatchers.jsonPath("$.errors").doesNotExist());
        }

        // API: getStudentById
        @Test
        public void shouldReturnSingleStudent() throws Exception {

                // 1. Mock data returned by studnetService.findOne
                Student stubbedStudnetInfo = new Student(Long.valueOf(1), "Ahmed", "Gouda", "softgate@hotmail.com");

                // NOTE: Long.valueOf is to wrap a long primitve by a Long object
                when(studentService.findOne(stubbedStudnetInfo.getId())).thenReturn(Optional.of(stubbedStudnetInfo));

                // 2. Create mock HTTP request and test it
                mockMvc.perform(MockMvcRequestBuilders.get("/api/students/" + stubbedStudnetInfo.getId()))
                                .andDo(MockMvcResultHandlers.print())
                                // check response status
                                .andExpect(status().isOk()) // 200
                                // check headers in repsonse
                                .andExpect(header().string("Content-Type", "application/json"))
                                // check not error
                                .andExpect(MockMvcResultMatchers.jsonPath("$.errors").doesNotExist()) // not an
                                                                                                      // exception
                                // check all properties exist on response object
                                .andExpect(MockMvcResultMatchers.jsonPath("$.id").exists())
                                .andExpect(MockMvcResultMatchers.jsonPath("$.firstName").exists())
                                .andExpect(MockMvcResultMatchers.jsonPath("$.lastName").exists())
                                .andExpect(MockMvcResultMatchers.jsonPath("$.email").exists())
                                // check all values
                                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(stubbedStudnetInfo.getId()))
                                .andExpect(MockMvcResultMatchers.jsonPath("$.firstName")
                                                .value(stubbedStudnetInfo.getFirstName()))
                                .andExpect(MockMvcResultMatchers.jsonPath("$.lastName")
                                                .value(stubbedStudnetInfo.getLastName()))
                                .andExpect(MockMvcResultMatchers.jsonPath("$.email")
                                                .value(stubbedStudnetInfo.getEmail()));
        }

        // API: getAllStudents
        @Test
        public void shouldReturnListOfStudents() throws Exception {
                // 2. Create mock HTTP request and test it
                mockMvc.perform(MockMvcRequestBuilders.get("/api/students")).andDo(MockMvcResultHandlers.print())
                                // check response status
                                .andExpect(status().isOk()) // 200
                                // check headers in repsonse
                                .andExpect(header().string("Content-Type", "application/json"))
                                // check not error
                                .andExpect(MockMvcResultMatchers.jsonPath("$.errors").doesNotExist()) // not an
                                // check it's an array
                                .andExpect(MockMvcResultMatchers.jsonPath("$").isArray());
        }

        // API: editStudent
        @Test
        public void shouldEditStudentSuccessfully() throws Exception {

                // 1. Mock data returned by studnetService.findOne
                Student stubbedStudnetInfo = new Student(Long.valueOf(1), "Ahmed", "Gouda", "softgate@hotmail.com");

                // NOTE: Long.valueOf is to wrap a long primitve by a Long object
                when(studentService.findOne(stubbedStudnetInfo.getId())).thenReturn(Optional.of(stubbedStudnetInfo));

                // 2. Mock the request body
                StudentDTO payload = new StudentDTO("Ahmed - Edited", "Gouda", "softgate@hotmail.com");

                // 3. Create mock HTTP request and test it
                mockMvc.perform(put("/api/students/" + stubbedStudnetInfo.getId())
                                .content(objectMapper.writeValueAsString(payload))
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
                                // check response status
                                .andExpect(status().isOk()) // 200
                                // check not error
                                .andExpect(MockMvcResultMatchers.jsonPath("$.errors").doesNotExist());
        }

        // API: deleteStudent
        @Test
        public void shouldDeleteStudentSuccessfully() throws Exception {

                // 1. Mock data returned by studnetService.findOne
                Student stubbedStudnetInfo = new Student(Long.valueOf(1), "Ahmed", "Gouda", "softgate@hotmail.com");

                // NOTE: Long.valueOf is to wrap a long primitve by a Long object
                when(studentService.findOne(stubbedStudnetInfo.getId())).thenReturn(Optional.of(stubbedStudnetInfo));

                // Create mock HTTP request and test it
                mockMvc.perform(delete("/api/students/" + stubbedStudnetInfo.getId())).andDo(print())
                                // check not error
                                .andExpect(MockMvcResultMatchers.jsonPath("$.errors").doesNotExist())
                                // check response status
                                .andExpect(status().isNoContent()); // 204
        }
}