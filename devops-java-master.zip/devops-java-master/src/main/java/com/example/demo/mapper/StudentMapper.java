package com.example.demo.mapper;

import java.util.List;

import com.example.demo.dto.StudentDTO;
import com.example.demo.model.Student;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StudentMapper {
    Student dtoToStudent(StudentDTO tudentDTO);

    StudentDTO studentToDTO(Student student);

    @IterableMapping(elementTargetType = StudentDTO.class)
    List<StudentDTO> studentsToDTO(List<Student> students);
}
