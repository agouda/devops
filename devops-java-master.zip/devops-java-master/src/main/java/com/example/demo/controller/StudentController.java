package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.dto.StudentDTO;
import com.example.demo.mapper.StudentMapper;
import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class StudentController {

	private static final String STUDENT_NOT_FOUND_TEMPLATE = "Student with id %s not found.";

	private final StudentService studentService;
	private final StudentMapper studentMapper;

	@GetMapping("/students")
	public ResponseEntity<List<StudentDTO>> getAllStudents() {
		return ResponseEntity.ok(studentMapper.studentsToDTO(studentService.findAll()));
	}

	@GetMapping("/students/{id}")
	public ResponseEntity<StudentDTO> getStudentById(@PathVariable Long id, Model model) {
		Student student = studentService.findOne(id).orElseThrow(
				() -> new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(STUDENT_NOT_FOUND_TEMPLATE, id)));
		return ResponseEntity.ok(studentMapper.studentToDTO(student));
	}

	@PostMapping("/students")
	public ResponseEntity<StudentDTO> addStudent(@Valid @RequestBody StudentDTO studentDTO, BindingResult result) {
		if (result.hasErrors()) {
			List<ObjectError> allErrors = result.getAllErrors();
			log.info("errors {} ", allErrors);
		}
		return ResponseEntity
				.ok(studentMapper.studentToDTO(studentService.save(studentMapper.dtoToStudent(studentDTO))));
	}

	@PutMapping("/students/{id}")
	public ResponseEntity<StudentDTO> editStudent(@PathVariable Long id, @Valid @RequestBody StudentDTO studentDTO,
			BindingResult result) {
		if (result.hasErrors()) {
			List<ObjectError> allErrors = result.getAllErrors();
			log.info("errors {} ", allErrors);
		}
		studentService.findOne(id).orElseThrow(
				() -> new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(STUDENT_NOT_FOUND_TEMPLATE, id)));
		studentDTO.setId(id);
		return ResponseEntity
				.ok(studentMapper.studentToDTO(studentService.save(studentMapper.dtoToStudent(studentDTO))));

	}

	@DeleteMapping("/students/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteStudent(@PathVariable Long id) {
		studentService.findOne(id).orElseThrow(
				() -> new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(STUDENT_NOT_FOUND_TEMPLATE, id)));
		studentService.delete(id);

	}
}
